from .visyn_server import create_visyn_server

app = create_visyn_server()
