from .model import get_global_settings, GlobalSettings  # NOQA
